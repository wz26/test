Name: Weijian Zheng
CS 55700 
Project 1: camera calibration


To run this script, simply call 
python project1.py

The value for each parameter and the average error will be printed. 